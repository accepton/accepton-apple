#import <UIKit/UIKit.h>

#import "stub.h"

FOUNDATION_EXPORT double acceptonVersionNumber;
FOUNDATION_EXPORT const unsigned char acceptonVersionString[];

