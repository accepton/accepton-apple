//This is needed as a 'public' header otherwise the build fails
extern NSString *const acceptonStubHeader;
